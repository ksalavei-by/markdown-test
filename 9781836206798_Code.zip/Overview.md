### Learn GitHub Flavored Markdown

---  

Description:

Markdown is a alternative to other markup languages such as HTML. There is a version that is a little more 'fancy' called GitHub Flavored Markdown. In this series, you will find out what GitHub-Flavored Markdown is as well as how to accomplish quick format tasks that simplify creating structure and some styling.

---

#### Outline:

* Fundamentals
  + [x] Writing Markdown  
* Text
  + [x] Italicizing Text
  + [x] Emphasizing Text
  + [x] Striking Through Text
  + [ ] Creating Headings
  + [ ] Creating A Blockquote
  + [ ] Creating A Heading with Underline
  + [ ] Adding an External Link  
  + [ ] Adding an Internal Link
* Lists
  + [ ] Creating A Bulleted List
  + [ ] Creating A Numbered List
* Images
  + [ ] Adding An Image
  + [ ] Creating an Image with Links
* Tables
  + [ ] Creating a Table  
* Code
  + [ ] Inlining Code
  + [ ] Creating a Code Block
* Above and Beyond
  + [ ] Creating a Task List
  + [ ] Using Emojis
